for (let notas of [
    Number(window.prompt("Qual a 1ª nota")), 
    Number(window.prompt("Qual a 2ª nota")), 
    Number(window.prompt("Qual a 3ª nota")), 
    Number(window.prompt("Qual a 4ª nota")), 
    Number(window.prompt("Qual a 5ª nota")), 
    Number(window.prompt("Qual a 6ª nota")),  
    Number(window.prompt("Qual a 7ª nota")),
 ]) {
     console.log('Nota: '+ notas)
 }