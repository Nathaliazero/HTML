let form = document.getElementById("form");
let textInput = document.getElementById("textInput");
let dateInput = document.getElementById("dateInput");
let textarea = document.getElementById("textarea");
let msg = document.getElementById("msg");
let tasks = document.getElementById("tasks");
let add = document.getElementById("add");

form.addEventListener("submit", (e) => {
    e.preventDefault();
    formValidation();
});

let formValidation = () => {
    if (textInput.value === "") {
        console.log("falhou");
        msg.innerHTML = "campo obrigátorio"
    } else { 
        console.log("sucesso");
         msg.innerHTML = "";
         acceptData();
        //add é o botao o "data-bs-dismiss faz ele fechar"  cricou o atributo
         add.setAttribute("data-bs-dismiss", "modal");
         add.click();

        //função anonima  chamando o atributo após o click.
         (()=>{
            add.setAttribute("data-bs-dismiss","modal");
         })();
         createTasks();
        }
};
let data = [];
let acceptData = () => {

    //esse push add alguma coisa nos arrays no caso o data[]; param == parametro
    // {} dentro do push para add varios valores
    // array vai guardar varios objetos. 
    data.push({
        text:textInput.value, //atributo text quero guardar um valor de texto
        date:dateInput.value, // quero guardar o valor data
        description:textarea.value, // descriçao no textarea
    });
    //guardando o array dentro do html do cliente
    localStorage.setItem("data", JSON.stringify(data));
    console.log(data);
};

let createTasks = ()=>{
    tasks.innerHTML = "";

    data.map((x,y)=>{
        return (tasks.innerHTML += `
            <div id=${y}> 
            <span class ="fw-bold">${x.text}</span>
            <span class ="small text-secondary">${x.text}</span>
            <p>${x.description}</p>

            <span class="options">
              <i onClick="editTask(this)" class="fas fa-edit" data-bs-toggle="model" data-bs-target="#form"></i>
              <i onClick="deleteTask(this);createTask()" class="fas fa-trash-alt"></i>
              </span>
            </div>`
            );
    });
    resetform()
};

let resetform = () =>{
    textInput.value = "";
    dateInput.value = "";
    textarea.value = "";
}



let deleteTask = (e) => {
    e.parentElement.parentElement.remove();
    data.splice(e.parentElement.parentElement.id, 1);
    localStorage.setItem("data", JSON.stringify(data));
    console.log(data);
}

let editTask = (e) => {
    let selectedTask = e.parentElement.parentElement;
    textInput.value = selectedTask.children[0].innerHTML;
    dateInput.value = selectedTask.children[1].innerHTML;
    textarea.value = selectedTask.children[2].innerHTML;
    deleteTask(e);
}
//TODO: re

//struck nao tem instancia, pode ter tudo em uma unica variavel
//class voce tem que ddeterminar tudo nela para preencer tudo com os msm dados